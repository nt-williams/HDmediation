HDmediation
================

<!-- badges: start -->
<!-- badges: end -->

Efficient, doubly-robust–and possibly transported–estimation of
interventional (in)direct effects with high-dimensional mediators and
mediator-outcome confounders.

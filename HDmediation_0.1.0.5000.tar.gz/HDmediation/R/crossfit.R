crossfit <- function(train, valid, y, x, type = c("binomial", "gaussian"),
                     id = NULL, learners = c("SL.mean", "SL.glm", "SL.glm.interaction", "SL.lightgbm", "SL.earth")) {
    fit <- regress(train, y, x, id, match.arg(type), learners = learners)
    lapply(valid, function(newX) predictt(fit, newX[, x, drop = FALSE]))
}

regress <- function(train, y, x, id, type, learners) {
    if (!is.null(id)) {
        id <- train[, id]
    }

    # fit <- glmnet3(train[, x, drop = FALSE], train[[y]], id = id, family = type)

    family <- ifelse(type == "binomial", binomial(), gaussian())
    fit <- SuperLearner::SuperLearner(
        train[[y]], train[, x, drop = FALSE], family = family[[1]],
        SL.library = c("SL.mean", "SL.glm", "SL.glm.interaction", "SL.lightgbm", "SL.earth", "SL.glmnet3"), id = id,
        method = "method.NNLS", env = environment(SuperLearner::SuperLearner)
    )

    fit
}

predictt <- function(fit, newX) {
    # predict.glmnet3(fit, newX)
    predict(fit, newX)$pred[, 1]
}
